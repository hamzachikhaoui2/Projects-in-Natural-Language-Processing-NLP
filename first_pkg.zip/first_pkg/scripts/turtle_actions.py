# !/user/bin/env python3
import rospy
from geometry_msgs.msg import Twist
from turtlesim.srv import SetPen  # Import the service type
import math
PI = math.pi

class Turtle():
    """Turtle object"""
    def __init__(self):
        # Initiate node
        rospy.init_node('turtle_controller', anonymous=True)
        
        # Create publiser: Turtle will publish to cmd_vel
        cmd_vel = '/turtle1/cmd_vel'
        self.vel_pub = rospy.Publisher(cmd_vel, Twist, queue_size=10)
        self.rate = rospy.Rate(10) # 10Hz

        # Creating Twist object (msg)
        self.vel_msg = Twist()

        # Service for setting pen color
        set_pen_service_name = '/turtle1/set_pen'
        rospy.wait_for_service(set_pen_service_name)  # Wait for the service to become available
        self.set_pen_service = rospy.ServiceProxy(set_pen_service_name, SetPen)
        rospy.loginfo("Service '/turtle1/set_pen' is ready.")        
    
    def rotate(self, angle=30, direction='counterclockwise', ang_speed=30):
        """Rotating turtle desired angle at nng_speed"""
        # angle and ang_speed are in deg
        rad_angle = angle*PI/180
        rad_speed = ang_speed*PI/180

        # Set angular velocity based on direction
        if direction == "counterclockwise" or direction == 'left':
            rad_speed = -abs(rad_speed)  # Negative for clockwise
        elif direction == "clockwise"or direction == 'right':
            rad_speed = abs(rad_speed)  # Positive for counterclockwise
        else:
            rospy.logwarn(f"Unknown orientation '{direction}'. Defaulting to counterclockwise.")
            rad_speed = abs(rad_speed)


        # We will only be rotating in z axis, so we don't need to
        # specify values for the rest of params of vel_msg cos by 
        # default are set to 0
        self.vel_msg.angular.z = rad_speed

        # Getting starting time
        t0 = rospy.Time.now().to_sec()
        current_angle = 0

        while (current_angle < rad_angle):
            # Publish velocity
            self.vel_pub.publish(self.vel_msg)
            self.rate.sleep()
            # Get current time
            t1 = rospy.Time.now().to_sec()
            current_angle = abs(rad_speed)*(t1-t0)

        # After compliting rotation
        self.vel_msg.angular.z = 0    
        self.vel_pub.publish(self.vel_msg)
        self.rate.sleep()

    def move(self, distance=2, direction='right', lin_vel=1):
        """Move turtle in a straight line a desired distance."""

        # Set linear velocity based on direction
        if direction == "left" or direction == "backward":
            self.vel_msg.linear.x = -abs(lin_vel)  # Negative velocity for left
        elif direction == "right" or direction == "forward":
            self.vel_msg.linear.x = abs(lin_vel)  # Positive velocity for right
        else:
            rospy.logwarn(f"Unknown direction '{direction}'. Defaulting to positive direction.")
            self.vel_msg.linear.x = abs(lin_vel)

        # Debug log for direction and velocity
        rospy.loginfo(f"Direction: {direction}, Velocity: {self.vel_msg.linear.x}")

        # Get initial time
        t0 = rospy.Time.now().to_sec()
        current_distance = 0

        while current_distance < distance:
            # Publish velocity
            self.vel_pub.publish(self.vel_msg)
            self.rate.sleep()

            # Get current time and calculate traveled distance
            t1 = rospy.Time.now().to_sec()
            current_distance = abs(self.vel_msg.linear.x) * (t1 - t0)  # Always positive

            # Debug log for distance
            rospy.loginfo(f"Current Distance: {current_distance}, Time Elapsed: {t1 - t0}")

        # Stop the turtle after moving
        self.vel_msg.linear.x = 0
        self.vel_pub.publish(self.vel_msg)
        self.rate.sleep()
        rospy.loginfo("Movement completed.")

   
    def square(self, limit=1):
        dist = 3
        for i in range(limit):
            for j in range(4):
                self.move(dist, lin_vel=3)
                self.rotate(90, ang_speed=60)
            dist -= 0.5

    def triangle(self):
        dist = 3
        for _ in range(3):
            self.move(dist, lin_vel=3)
            self.rotate(120, ang_speed=60)

    def draw(self, figure):
        if figure == 'square':
            self.square()
        if figure == 'triangle':
            self.triangle()
        
    # TODO: MODIFICAR ESTAS DOS FUNCIONES PARA QUE FUNCIONEN
    # def change_color(self, color):
    #     """Change the pen color of the turtle."""
    #     # Define color map
    #     color_map = {
    #         "red": (255, 0, 0),
    #         "green": (0, 255, 0),
    #         "blue": (0, 0, 255),
    #         "black": (0, 0, 0),
    #         "yellow": (255, 255, 0),
    #         "white": (255, 255, 255)
    #     }

    #     # Get RGB values for the color
    #     if color in color_map:
    #         r, g, b = color_map[color]
    #     else:
    #         rospy.logwarn(f"Color '{color}' is not recognized. Defaulting to black.")
    #         r, g, b = 0, 0, 0  # Default to black

    #     # Call the set_pen service
    #     try:
    #         self.set_pen_service(r, g, b, 1, 0)  # Default width: 1, off: 0
    #         rospy.loginfo(f"Pen color changed to {color}")
    #     except rospy.ServiceException as e:
    #         rospy.logerr(f"Failed to change color: {e}")   
    def change_color(self, color):
        """Change the pen color of the turtle."""
        # Define color map
        color_map = {
            "red": (255, 0, 0),
            "green": (0, 255, 0),
            "blue": (0, 0, 255),
            "black": (0, 0, 0),
            "yellow": (255, 255, 0),
            "white": (255, 255, 255)
        }

        # Get RGB values for the color
        if color in color_map:
            r, g, b = color_map[color]
        else:
            rospy.logwarn(f"Color '{color}' is not recognized. Defaulting to black.")
            r, g, b = 0, 0, 0  # Default to black

        # Debugging info
        rospy.loginfo(f"Attempting to set pen color to {color} (RGB: {r}, {g}, {b})")

        # Call the set_pen service
        try:
            self.set_pen_service(r, g, b, 3, 0)  # width=3, off=0
            rospy.loginfo(f"Successfully changed pen color to {color}")
        except rospy.ServiceException as e:
            rospy.logerr(f"Failed to change pen color: {e}")


    def pen_down(self, is_pendown):
        """Set the pen state to down or up."""
        try:
            if is_pendown:
                self.set_pen_service(0, 0, 0, 1, 0)  # Enable drawing (off=0)
                rospy.loginfo("Pen is now down (drawing).")
            else:
                self.set_pen_service(0, 0, 0, 1, 1)  # Disable drawing (off=1)
                rospy.loginfo("Pen is now up (not drawing).")
        except rospy.ServiceException as e:
            rospy.logerr(f"Failed to set pen state: {e}")


if __name__ == '__main__':
    try:
        turtle = Turtle()

        # Retrieve and log the command
        command = rospy.get_param("command")
        rospy.loginfo(f"Command: {command}")

        params = rospy.get_param("actions")
        num_actions = params["number_of_actions"]

        
        for i in range(1, num_actions + 1):
            action = params[f"action{i}"]
            action_type = action["action_type"]

            if action_type == "move":
                direction = action["direction"]
                distance = action["distance"]

                # Check if 'velocity' exists in the action dictionary
                if "lin_velocity" in action:
                    velocity = action["lin_velocity"]
                    rospy.loginfo(f"Executing move: {direction}, {distance}, {velocity}")
                    turtle.move(distance=distance, direction=direction, lin_vel=velocity)
                else:
                    rospy.loginfo(f"Executing move: {direction}, {distance}")
                    turtle.move(distance=distance, direction=direction)            

            elif action_type == "rotate":
                orientation = action["direction"]
                angle = action["angle"]
                rospy.loginfo(f"Executing rotate: {orientation}, {angle}")
 
                if "ang_velocity" in action:
                    velocity = action["ang_velocity"]
                    rospy.loginfo(f"Executing rotate: {orientation}, {angle}, {velocity}")
                    turtle.rotate(angle=angle, direction=orientation, lin_vel=velocity)
                else:
                    rospy.loginfo(f"Executing rotate: {orientation}, {angle}")
                    turtle.rotate(angle=angle, direction=orientation)                        

            elif action_type == "draw":
                figure = action["figure"]
                rospy.loginfo(f"Executing draw: {figure}")
                turtle.draw(figure) 

            # TODO: REVISAR QUE ESTAS DOS FUNCIONES FUNCIONEN
            elif action_type == "change_colors":
                color = action["color"]
                rospy.loginfo(f"Change color to: {color}")
                turtle.change_color(color)

            elif action_type == "pen_down":
                is_pendown = action["is_pendown"]
                rospy.loginfo(f"Is pen down?: {is_pendown}")
                turtle.pen_down(is_pendown)

            else:
                rospy.loginfo("The action is not possible to execute")
    
    except rospy.ROSInterruptException:
        pass

